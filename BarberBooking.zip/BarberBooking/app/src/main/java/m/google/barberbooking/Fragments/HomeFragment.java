package m.google.barberbooking.Fragments;


import android.content.Intent;
import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.accountkit.AccountKit;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import m.google.barberbooking.BookingActivity;
import m.google.barberbooking.Common.Common;
import m.google.barberbooking.Interface.IBannerLoadListener;
import m.google.barberbooking.Interface.ILookBookLoadListener;
import m.google.barberbooking.R;
import m.google.barberbooking.adapter.HomeAdapter;
import m.google.barberbooking.adapter.LookBookAdapter;
import m.google.barberbooking.modelo.Banner;
import m.google.barberbooking.service.PicassoImageLoadingService;
import ss.com.bannerslider.Slider;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment implements IBannerLoadListener, ILookBookLoadListener {

    Unbinder unbinder;

    @BindView(R.id.Id_layout_user_information)
    LinearLayout layout_user_information;

    @BindView(R.id.IdTxtUserName)
    TextView txtUserName;

    @BindView(R.id.IdBannerSlider)
    Slider bannerSlider;

    @BindView(R.id.IdRecycler_Look_Book)
    RecyclerView recyclerView;

    @OnClick(R.id.Id_cardview_booking)
     void booking()
    {
        startActivity(new Intent(getActivity(), BookingActivity.class));
    }

    //Firestore
    CollectionReference banneRef, lookRef;

    //interface
    IBannerLoadListener iBannerLoadListener;
    ILookBookLoadListener iLookBookLoadListener;


    public HomeFragment() {
        banneRef= FirebaseFirestore.getInstance().collection("Banner");
        lookRef= FirebaseFirestore.getInstance().collection("LookBook");
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_home, container, false);
        unbinder= ButterKnife.bind(this,view);

        //Init
        Slider.init(new PicassoImageLoadingService());
        iBannerLoadListener= this;
        iLookBookLoadListener=this;

        //check is logged?

        if(AccountKit.getCurrentAccessToken() !=null)
        {
            setUserInformation();
            loadBanner();
            loadLookBook();
        }


        return view;
    }

    private void loadLookBook() {
        lookRef.get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        List<Banner> lookbook= new ArrayList<>();
                        if (task.isSuccessful())
                        {
                            for (QueryDocumentSnapshot snapshot: task.getResult())
                            {
                                Banner banner= snapshot.toObject(Banner.class);
                                lookbook.add(banner);
                            }
                            iLookBookLoadListener.ILookLoadSucces(lookbook);
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                iLookBookLoadListener.ILookLoadOnFailed(e.getMessage());
            }
        });

    }

    private void loadBanner() {

        banneRef.get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        List<Banner> banners= new ArrayList<>();
                        if (task.isSuccessful())
                        {
                            for (QueryDocumentSnapshot snapshot: task.getResult())
                            {
                                Banner banner= snapshot.toObject(Banner.class);
                                banners.add(banner);
                            }
                            iBannerLoadListener.IBannerLoadSucces(banners);
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                iBannerLoadListener.IBannerLoadOnFailed(e.getMessage());
            }
        });
    }

    private void setUserInformation() {
        layout_user_information.setVisibility(View.VISIBLE);
        txtUserName.setText(Common.currentUser.getName());



    }

    @Override
    public void IBannerLoadSucces(List<Banner> banners) {
       bannerSlider.setAdapter(new HomeAdapter(banners));
    }

    @Override
    public void IBannerLoadOnFailed(String message) {
        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void ILookLoadSucces(List<Banner> banners) {
           recyclerView.setHasFixedSize(true);
           recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
           recyclerView.setAdapter(new LookBookAdapter(banners, getActivity()));

    }

    @Override
    public void ILookLoadOnFailed(String message) {
        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
    }
}
