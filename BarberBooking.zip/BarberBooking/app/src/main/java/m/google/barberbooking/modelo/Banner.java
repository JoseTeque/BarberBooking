package m.google.barberbooking.modelo;

public class Banner {

    // Banner ando lookbook same
    private String image;

    public Banner() {
    }

    public Banner(String image) {
        this.image = image;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
