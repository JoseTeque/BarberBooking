package m.google.barberbooking.Fragments;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;
import m.google.barberbooking.Common.Common;
import m.google.barberbooking.R;
import m.google.barberbooking.modelo.BookingInformation;

public class BookingStep4Fragment extends Fragment {

    SimpleDateFormat simpleDateFormat;
    LocalBroadcastManager localBroadcastManager;

    Unbinder unbinder;

    @BindView(R.id.IdTxtName_Salon)
    TextView txtNameSalon;

    @BindView(R.id.IdTxtLocation)
    TextView txtLocation;

    @BindView(R.id.IdTxtWebSite)
    TextView txtWebSite;

    @BindView(R.id.IdTxtPhone)
    TextView txtPhone;

    @BindView(R.id.IdTxtOpenTime)
    TextView txtOpenTime;

    @BindView(R.id.IdTxtTimeBooking)
    TextView txtTimeBookingInformation;

    @BindView(R.id.IdTxtNameBooking)
    TextView txtNameBookingInformation;

    @OnClick(R.id.IdBtnConfirmar)
    void confirm() {

        //create booking information
        BookingInformation bookingInformation = new BookingInformation();

        bookingInformation.setBarberId(Common.currentBarber.getBarberId());
        bookingInformation.setBarberName(Common.currentBarber.getName());
        bookingInformation.setCustomerName(Common.currentUser.getName());
        bookingInformation.setCustomerPhone(Common.currentUser.getPhone());
        bookingInformation.setSalonId(Common.currentSalon.getSalonId());
        bookingInformation.setSalonAddress(Common.currentSalon.getAddress());
        bookingInformation.setSalonName(Common.currentSalon.getName());
        bookingInformation.setTime(Common.convertTimeSlotToString(Common.currentTimeSlot) +
                "at" +
                simpleDateFormat.format(Common.currentDate.getTime()));
        bookingInformation.setSlot((long) Common.currentTimeSlot);

        //submit to barber document

        DocumentReference documentReference = FirebaseFirestore.getInstance().collection("AllSalon")
                .document(Common.city)
                .collection("Branch")
                .document(Common.currentSalon.getSalonId())
                .collection("Barber")
                .document(Common.currentBarber.getBarberId())
                .collection(Common.simpleDateFormt.format(Common.currentDate.getTime()))
                .document(String.valueOf(Common.currentTimeSlot));

        //write data

        documentReference.set(bookingInformation)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        getActivity().finish();
                        Toast.makeText(getContext(), "Success!", Toast.LENGTH_SHORT).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getContext(), ""+ e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    BroadcastReceiver confirmBookingReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            setData();
        }
    };

    private void setData() {

        txtNameSalon.setText(Common.currentBarber.getName());
        txtTimeBookingInformation.setText(new StringBuilder(Common.convertTimeSlotToString(Common.currentTimeSlot))
                .append("at")
                .append(simpleDateFormat.format(Common.currentDate.getTime())));

        txtLocation.setText(Common.currentSalon.getAddress());
        txtWebSite.setText(Common.currentSalon.getWebSite());
        txtOpenTime.setText(Common.currentSalon.getOpenHor());
        txtPhone.setText(Common.currentSalon.getPhone());
        txtNameBookingInformation.setText(Common.currentSalon.getName());
    }


    static BookingStep4Fragment instance;

    public static BookingStep4Fragment getInstance() {
        if (instance == null)
            instance = new BookingStep4Fragment();
        return instance;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        simpleDateFormat = new SimpleDateFormat("dd/MM/yyy");

        localBroadcastManager = LocalBroadcastManager.getInstance(getContext());
        localBroadcastManager.registerReceiver(confirmBookingReceiver, new IntentFilter(Common.KEY_CONFIRM_BOOKING));
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);

        View view = inflater.inflate(R.layout.fragment_booking_step_four, container, false);

        unbinder = ButterKnife.bind(this, view);

        return view;
    }

    @Override
    public void onDestroy() {
        localBroadcastManager.unregisterReceiver(confirmBookingReceiver);
        super.onDestroy();
    }
}
