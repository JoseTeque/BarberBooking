package m.google.barberbooking.Interface;

import android.view.View;

public interface IRecyclerItemSelectedListener {

    void onItemListener(View view, int position);
}
